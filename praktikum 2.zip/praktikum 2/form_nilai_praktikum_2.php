<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">

    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Form Nilai Mahasiswa</title>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header text-white bg-primary">
                <h6>Sistem Penilaian</h6>
            </div>
            <div class="card-body">
                <h5>Form Nilai Mahasiswa</h5>
                <hr/>
                <form method="POST" action="nilai_mahasiswa_praktikum_2.php">
                    <div class="row">
                        <div class="offset-2"></div>
                        <div class="col-md-8">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Nama Lengkap :</label>
                                <div class="col-sm-9">
                                    <input type="text" name="nama" id="nama" class="form-control" value="" size="30" placeholder="Nama Lengkap">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">NIM :</label>
                                <div class="col-sm-9">
                                    <input type="text" name="nim" id="nim" class="form-control" value="" size="30" placeholder="NIM">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Mata Kuliah :</label>
                                <div class="col-sm-9">
                                  <select id="duration" name="matkul" class="form-control">
                                        <option value="Dasar - Dasar Pemrograman">Dasar - Dasar Pemrograman</option>
                                        <option value="Basis Data I">Basis Data I</option>
                                        <option value="Pemrograman Web">Pemrograman Web</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Nilai UTS :</label>
                                <div class="col-sm-9">
                                <input type="text" name="nilai_uts" id="nilai_uts" class="form-control" value="" size="6" placeholder="Nilai UTS">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Nilai UAS :</label>
                                <div class="col-sm-9">
                                <input type="text" name="nilai_uas" id="nilai_uas" class="form-control" value="" size="6" placeholder="Nilai UAS">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label">Nilai Tugas Praktikum :</label>
                                <div class="col-sm-9">
                                <input type="text" name="nilai_tugas" id="nilai_tugas" class="form-control" value="" size="6" placeholder="Nilai Tugas Praktikum">
                                </div>
                            </div>
                            <div class="offset-3 pl-2">
                                <input type="submit" class="btn btn-primary" value="SIMPAN" name="proses">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="text-center p-3" style="background-color: #1089ff;">
            <a class="text-white" href="https://github.com/alfisyhari" target=_blank>© 2021 Copyright: Alfisyhari</a>
            </div>
</body>
</html>